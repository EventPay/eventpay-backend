<p>&nbsp;</p>

<p>&nbsp;</p>

<p><span style="font-size:14px">Hello {{ $user->firstname }},<br />
        <br />
        You have successfully purchased a ticket for the event {{ $eventTicket->event->title }}<br />
        <br />

        <br />
        <br />
        <br />
        &nbsp;
</p>
