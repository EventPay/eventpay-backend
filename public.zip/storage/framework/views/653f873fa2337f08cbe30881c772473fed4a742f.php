<p>&nbsp;</p>

<p>&nbsp;</p>

<p><span style="font-size:14px">Hello <?php echo e($user->firstname); ?>,<br />
        <br />
        Enter the code to complete your email verification<br />
        <br />
        <?php echo e($code); ?><br />
        <br />
        Kindly ignore this email if you did not</span><span style="font-size:14px"> initiate this request</span><br />
    <br />
    &nbsp;
</p>
<?php /**PATH C:\xampp\htdocs\eventpay\resources\views/email/verification.blade.php ENDPATH**/ ?>