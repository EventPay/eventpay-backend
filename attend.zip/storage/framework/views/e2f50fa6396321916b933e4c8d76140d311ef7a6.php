
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                

                <div class="col-md-12">

                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Search Event</strong>
                        </div>

                        <div class="card-body">
                            <div class="row">

                        
                            <form class="col-md-5" action="" method="GET">

                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" name="q" placeholder="Enter a keyword"value="<?php if($search) echo $search ?>">
                                    <span class="input-group-text" id="basic-addon1"><i class="fa fa-search"></i></span>
                                  </div>

                                  <button class="btn btn-primary">
                                    Search
                                  </button>
                            </form>

                            </div>
                        </div>
                    </div>

                </br>
                <?php if($search): ?>
                <div class="search-info py-2 h5 fw-normal text-center text-dark">
                    Results for search query "<?php echo e($search); ?>"
                </div>
                <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Recent Events</strong>
                        </div>
                        <div class="table-stats order-table ov-h">
                            <table class="table ">
                                <thead>
                                    <tr>
                                        <th class="serial">#</th>
                                        <th class="avatar"></th>
                                        <th>Date</th>
                                        <th>Title</th>
                                        <th>Tickets</th>
                                        <th>Attending</th>
                                        <th>Status</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($event->id); ?></td>
                                            <td class="avatar">
                                                <div class="round-img">
                                                    <a href="#"><img class="rounded-circle"
                                                            src="<?php echo e($event->cover_image); ?>" alt=""></a>
                                                </div>
                                            </td>
                                            <td><?php echo e(show_date($event->startDate)); ?></td>
                                            <td><?php echo e($event->title); ?></td>
                                            <td><?php echo e(sizeOf($event->tickets)); ?></td>
                                            <td><?php echo e(44); ?></td>
                                            <td><?php echo e($event->status); ?></td>
                                            <td>

                                                <a class="btn btn-sm btn-warning" href="<?php echo e(route("admin.edit-event",['id' => $event->id])); ?>">
                                                    Edit <i class="fa fa-pencil"></i>
                                                </a>

                                                <button class="btn btn-primary btn-sm">
                                                    View <i class="fa fa-eye"></i>
                                                </button>


                                            </td>
                                            <td>
                                            
                                                <a href="#" class="btn btn-success btn-sm">View <i class="fa fa-eye"></i> </a>
                                                <a href="<?php echo e(route("suspend-event")); ?>" class="btn btn-danger btn-sm">Suspend <i class="fa fa-not-allowed"></i> </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div> <!-- /.table-stats -->
                    </div>
                </div>

            </div>
        </div>
    </div><!-- .animated -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eventpay\resources\views/admin/events.blade.php ENDPATH**/ ?>