
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                

                <div class="col-md-12">

                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Search Event</strong>
                        </div>

                        <div class="card-body">
                            <div class="row">


                                <form class="col-md-5" action="" method="GET">
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" placeholder="Enter user email,name or ID" name="q">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-search"></i></span>
                                    </div>

                                    <button class="btn btn-primary">
                                        Search
                                    </button>
                                </form>

                            </div>
                        </div>
                    </div>

                    <?php if($search): ?>
                    <div class="search-info py-2 h5 fw-normal text-center text-dark">
                        Results for search query "<?php echo e($search); ?>"
                    </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Recent Users</strong>
                        </div>
                        <div class="table-stats order-table ov-h">
                            <table class="table ">
                                <thead>
                                    <tr>
                                        <th class="serial">#</th>
                                        <th class="avatar"></th>
                                        <th>Name</th>
                                        <th>E-mail Address</th>
                                        <th>Phone Number</th>
                                        <th>Joined</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->id); ?></td>
                                            <td class="avatar">
                                                <div class="round-img">
                                                    <a href="#"><img class="rounded-circle"
                                                            src="<?php echo e($user->profile_image); ?>" alt=""></a>
                                                </div>
                                            </td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo e($user->phone); ?></td>
                                            <td><?php echo e(show_date($user->created_at)); ?></td>
                                            <td>
                                                <button class="btn btn-primary btn-sm">
                                                    View <i class="fa fa-eye"></i>
                                                </button>


                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div> <!-- /.table-stats -->
                    </div>
                </div>

            </div>
        </div>
    </div><!-- .animated -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eventpay\resources\views/admin/users.blade.php ENDPATH**/ ?>