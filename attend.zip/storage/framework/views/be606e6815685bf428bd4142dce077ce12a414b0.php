
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                

                <div class="col-md-12">


                    <div class="breadcrumbs">
                        <div class="breadcrumbs-inner">
                            <div class="row m-0">
                                <div class="col-sm-4">
                                    <div class="page-header float-left">
                                        <div class="page-title">
                                            <h1>Edit Event</h1>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-8">
                                    <div class="page-header float-right">
                                        <div class="page-title">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    </br>

                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title"><?php echo e($event->title); ?></strong>
                        </div>

                        <div class="card-body">
                            <form>

                                <div class="mb-3">
                                    <label>Title</label>
                                    <input type="text" class="form-control" name="title" value="<?php echo e($event->title); ?>">
                                </div>


                                <button class="btn btn-primary btn-sm">Submit</button>

                            </form>

                            <small class="text-secondary py-3">
                                Other actions*
                            </small>

                            <div class="button-group">
                            <button class="btn btn-sm btn-danger">
                                Suspend Event
                            </button>
                            </div>


                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div><!-- .animated -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eventpay\resources\views/admin/edit_event.blade.php ENDPATH**/ ?>