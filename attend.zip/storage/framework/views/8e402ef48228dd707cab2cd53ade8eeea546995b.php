curl -X <?php echo e($route['methods'][0]); ?> <?php echo e($route['methods'][0] == 'GET' ? '-G ' : ''); ?>"<?php echo e(trim(config('app.docs_url') ?: config('app.url'), '/')); ?>/<?php echo e(ltrim($route['uri'], '/')); ?>" <?php if(count($route['headers'])): ?>\
<?php $__currentLoopData = $route['headers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    -H "<?php echo e($header); ?>: <?php echo e($value); ?>"<?php if(! ($loop->last) || ($loop->last && count($route['bodyParameters']))): ?> \
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__currentLoopData = $route['bodyParameters']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute => $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    -d "<?php echo e($attribute); ?>"="<?php echo $parameter['value'] === false ? "false" : $parameter['value']; ?>" <?php if(! ($loop->last)): ?>\
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\eventpay\vendor\ovac\idoc\src\idoc/../../resources/views//languages/bash.blade.php ENDPATH**/ ?>