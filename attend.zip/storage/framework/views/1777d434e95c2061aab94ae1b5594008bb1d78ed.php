
$headers = [
<?php $__currentLoopData = $route['headers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    "<?php echo e($header); ?>" => "<?php echo e($value); ?>",
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(!array_key_exists('Accept', $route['headers'])): ?>
    "Accept" => "application/json",
<?php endif; ?>
<?php if(!array_key_exists('Content-Type', $route['headers'])): ?>
    "Content-Type" => "application/json",
<?php endif; ?>
];
<?php if(count($route['bodyParameters'])): ?>

$body = [
<?php $__currentLoopData = $route['bodyParameters']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute => $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    "<?php echo e($attribute); ?>" => <?php if(in_array($parameter['type'], ['json', 'object', 'array'])): ?>"json_decode(<?php echo $parameter['value']; ?>, true)"<?php else: ?> "<?php echo e($parameter['value']); ?>"<?php endif; ?>,
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
];
<?php endif; ?>
<?php if(count($route['queryParameters'])): ?>

$query = [
<?php $__currentLoopData = $route['queryParameters']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute => $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    "<?php echo e($attribute); ?>" => "<?php echo e($parameter['value']); ?>",
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
];
<?php endif; ?>

<?php
    $urlVlaue = rtrim(config('app.docs_url') ?: config('app.url'), '/') . '/' . ltrim($route['uri'], '/');
    $urlParams = '';
    if(count($route['queryParameters'])) {
        $urlVlaue .= '?';
        $urlParams = 'http_build_query($data)';
    }
?>

$ch = curl_init("<?php echo e($urlVlaue); ?>"<?php echo e($urlParams ? ' . ' . $urlParams : ''); ?>);
<?php if (! ($route['methods'][0] === 'GET')): ?>
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "<?php echo e($route['methods'][0]); ?>");
<?php endif; ?>
<?php if($route['methods'][0] === 'POST' && count($route['bodyParameters'])): ?>
curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
<?php endif; ?>
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$result = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

if ($err) {
  throw \Exception($err);
} else {
  return $response;
}
<?php /**PATH C:\xampp\htdocs\eventpay\vendor\ovac\idoc\src\idoc/../../resources/views//languages/php.blade.php ENDPATH**/ ?>