<p>&nbsp;</p>

<p>&nbsp;</p>

<p><span style="font-size:14px">Hello {{ $user->firstname }},<br />
        <br />
        Enter the code to reset your password<br />
        <br />
        {{ $code }}<br />
        <br />
        Kindly ignore this email if you did not</span><span style="font-size:14px"> initiate this request</span><br />
    <br />
    &nbsp;
</p>
